import React from "react";
import ReactDom from "react-dom";
ReactDom.render(
  <div>
    <h1>My favourite foods</h1>
    <ul>
      <li>Mango</li>
      <li>Grape</li>
      <li>Banana</li>
    </ul>
  </div>,
  document.getElementById("root")
);
